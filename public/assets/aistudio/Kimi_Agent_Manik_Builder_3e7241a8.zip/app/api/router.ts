import { authRouter } from "./auth-router";
import { designRouter } from "./design-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  design: designRouter,
});

export type AppRouter = typeof appRouter;
