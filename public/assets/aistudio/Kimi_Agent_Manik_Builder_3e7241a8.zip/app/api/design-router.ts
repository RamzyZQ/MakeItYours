import { and, desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { designs } from "@db/schema";
import { BASE_TYPES, MAX_BEADS_PER_DESIGN } from "@contracts/beads";
import { authedQuery, createRouter } from "./middleware";
import { getDb } from "./queries/connection";

const beadSchema = z.object({
  type: z.string().min(1).max(40),
  s: z.number().min(0).max(10000),
});

const beadsInput = z.array(beadSchema).max(MAX_BEADS_PER_DESIGN);

async function assertOwnDesign(userId: number, id: number) {
  const [row] = await getDb()
    .select()
    .from(designs)
    .where(and(eq(designs.id, id), eq(designs.userId, userId)))
    .limit(1);
  if (!row) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Desain tidak ditemukan" });
  }
  return row;
}

export const designRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    return getDb()
      .select()
      .from(designs)
      .where(eq(designs.userId, ctx.user.id))
      .orderBy(desc(designs.updatedAt));
  }),

  byId: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      return assertOwnDesign(ctx.user.id, input.id);
    }),

  create: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(120),
        baseType: z.enum(BASE_TYPES),
        beads: beadsInput,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const result = await getDb()
        .insert(designs)
        .values({
          userId: ctx.user.id,
          name: input.name,
          baseType: input.baseType,
          beads: JSON.stringify(input.beads),
          beadCount: input.beads.length,
        });
      return { id: Number(result[0].insertId) };
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        name: z.string().min(1).max(120),
        beads: beadsInput,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      await assertOwnDesign(ctx.user.id, input.id);
      await getDb()
        .update(designs)
        .set({
          name: input.name,
          beads: JSON.stringify(input.beads),
          beadCount: input.beads.length,
        })
        .where(eq(designs.id, input.id));
      return { id: input.id };
    }),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      await assertOwnDesign(ctx.user.id, input.id);
      await getDb().delete(designs).where(eq(designs.id, input.id));
      return { success: true };
    }),
});
