// Shared bead-studio contracts (frontend <-> backend)

export const BASE_TYPES = ["kalung", "gelang", "strap"] as const;
export type BaseType = (typeof BASE_TYPES)[number];

export interface BeadRecord {
  /** bead definition id from the catalog */
  type: string;
  /** arc-length position along the string path (viewBox units) */
  s: number;
}

export const BASE_TYPE_LABELS: Record<BaseType, string> = {
  kalung: "Rantai Kalung",
  gelang: "Tali Gelang",
  strap: "Strap",
};

export const MAX_BEADS_PER_DESIGN = 24;
