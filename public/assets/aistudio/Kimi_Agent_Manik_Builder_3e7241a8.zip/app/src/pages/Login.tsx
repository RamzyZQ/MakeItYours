import { Link } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="grain flex min-h-dvh flex-col items-center justify-center bg-background px-4">
      <Card className="w-full max-w-sm rounded-[13.5px] border-foreground/70">
        <CardHeader className="items-center text-center">
          <svg viewBox="-20 -20 40 40" className="mb-2 h-10 w-10" aria-hidden>
            <circle r="14" fill="#B39C4F" />
            <circle r="6" fill="#F8F7E5" />
          </svg>
          <CardTitle className="font-display text-2xl">Masuk ke Manik Studio</CardTitle>
          <p className="mt-1 text-sm text-foreground/60">
            Simpan rangkaian manikmu dan buka kembali dari galeri pribadi.
          </p>
        </CardHeader>
        <CardContent>
          <button
            type="button"
            className="btn-pill-gold w-full"
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
          >
            Masuk dengan Kimi
          </button>
          <Link
            to="/"
            className="meta-label mt-4 flex items-center justify-center gap-1.5 py-2 text-foreground/55 transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
            Kembali ke beranda
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
