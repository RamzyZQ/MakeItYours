import { useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router";
import AppHeader from "@/components/AppHeader";
import StringCanvas from "@/components/StringCanvas";
import { getPath, topS } from "@/game/paths";
import { BEADS } from "@/game/beads";
import { useStringSim } from "@/game/sim";
import { BASE_TYPE_LABELS, type BaseType } from "@contracts/beads";
import { ArrowRight, MoveDown, MousePointer2, Layers } from "lucide-react";

const BASE_CARDS: { base: BaseType; desc: string }[] = [
  { base: "kalung", desc: "Kurva-U terbuka · manik menumpuk di titik terendah" },
  { base: "gelang", desc: "Lingkar penuh · manik mengalir memutari tali" },
  { base: "strap", desc: "Loop oval memanjang · untuk gantungan & strap" },
];

function HeroDemo() {
  const path = getPath("kalung");
  const { beads, addBead, clear } = useStringSim(path);
  const countRef = useRef(0);

  useEffect(() => {
    const top = topS(path);
    const timer = setInterval(() => {
      if (countRef.current >= 11) {
        countRef.current = 0;
        clear();
        return;
      }
      const def = BEADS[Math.floor(Math.random() * BEADS.length)];
      const spread = path.length * 0.28;
      const s = top + (Math.random() - 0.5) * spread + (Math.random() < 0.5 ? -spread : spread);
      addBead(def.id, Math.max(30, Math.min(path.length - 30, s)));
      countRef.current += 1;
    }, 1400);
    return () => clearInterval(timer);
  }, [path, addBead, clear]);

  return (
    <div className="reveal reveal-2">
      <StringCanvas path={path} beads={beads} tone="dark" beadScale={0.92} />
      <p className="meta-label mt-3 flex items-center gap-2 text-foreground/55">
        <MoveDown className="h-3.5 w-3.5" aria-hidden />
        Demo langsung — manik meluncur mengikuti gravitasi kurva
      </p>
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="grain min-h-dvh bg-background">
      <AppHeader />

      {/* ---- Hero ---- */}
      <section className="mx-auto grid max-w-6xl gap-10 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:pt-20">
        <div>
          <p className="meta-label reveal text-foreground/60">
            Studio merangkai interaktif — Jakarta
          </p>
          <h1 className="reveal reveal-1 mt-5 font-display text-[13vw] font-black leading-[0.98] tracking-tight sm:text-6xl lg:text-7xl">
            Rangkai manik.
            <br />
            Biarkan{" "}
            <span className="text-primary">gravitasi</span>
            <br />
            yang bekerja.
          </h1>
          <p className="reveal reveal-2 mt-6 max-w-[52ch] text-base leading-relaxed text-foreground/75 sm:text-lg">
            Seret manik dari katalog, jatuhkan di atas tali, dan saksikan ia
            mengikat pada jalur kurva lalu meluncur turun — menumpuk rapi di
            slot terendah yang kosong, persis manik sungguhan.
          </p>
          <div className="reveal reveal-3 mt-8 flex flex-wrap items-center gap-3">
            <a href="#pilih" className="btn-pill-gold">
              Mulai Merangkai
              <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
            <Link to="/galeri" className="btn-pill-outline">
              Lihat Galeri
            </Link>
          </div>
        </div>

        <HeroDemo />
      </section>

      {/* ---- Base selection ---- */}
      <section id="pilih" className="rule-y">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[300px_1fr]">
          <div className="reveal">
            <p className="meta-label text-foreground/60">Langkah 01 — Media dasar</p>
            <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight">
              Pilih tali
              <br />
              dasarmu
            </h2>
            <p className="mt-4 text-base leading-relaxed text-foreground/70">
              Setiap media punya jalur kurva yang berbeda. Manik akan selalu
              mencari titik terendah — di mana pun kamu menjatuhkannya.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            {BASE_CARDS.map(({ base, desc }, idx) => {
              const path = getPath(base);
              return (
                <button
                  key={base}
                  type="button"
                  onClick={() => navigate(`/builder/${base}`)}
                  style={{ animationDelay: `${idx * 0.09}s` }}
                  className="reveal group flex flex-col rounded-[13.5px] border border-foreground/70 bg-card p-5 text-left transition-colors duration-150 hover:bg-foreground focus-visible:outline-2 focus-visible:outline-ring"
                >
                  <span className="meta-label text-foreground/50 group-hover:text-background/60">
                    {String(idx + 1).padStart(2, "0")}
                  </span>
                  <svg viewBox="120 40 760 560" className="mt-4 h-36 w-full" aria-hidden>
                    <path
                      d={path.d}
                      className="string-line-static"
                      stroke="currentColor"
                      strokeWidth={4}
                      opacity={0.9}
                    />
                    {!path.closed && (
                      <>
                        <circle cx={path.samples[0].x} cy={path.samples[0].y} r={14} fill="#B39C4F" />
                        <circle
                          cx={path.samples[path.samples.length - 1].x}
                          cy={path.samples[path.samples.length - 1].y}
                          r={14}
                          fill="#B39C4F"
                        />
                      </>
                    )}
                  </svg>
                  <span className="mt-4 font-display text-2xl font-semibold group-hover:text-background">
                    {BASE_TYPE_LABELS[base]}
                  </span>
                  <span className="mt-2 font-mono text-[11px] leading-relaxed text-foreground/60 group-hover:text-background/70">
                    {desc}
                  </span>
                  <span className="meta-label mt-4 flex items-center gap-1.5 text-primary group-hover:text-[#B39C4F]">
                    Pilih
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" aria-hidden />
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ---- Physics band (inverted) ---- */}
      <section className="bg-[#1D1D1D] text-[#F8F7E5]">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.2fr_1fr_1fr_1fr]">
          <div>
            <p className="meta-label text-[#B39C4F]">Cara kerja</p>
            <h2 className="mt-4 font-display text-3xl font-semibold tracking-tight">
              Fisika tali sungguhan
            </h2>
          </div>
          {[
            {
              icon: MousePointer2,
              title: "Snapping to path",
              body: "Saat dilepas, manik mengikat otomatis ke titik terdekat pada jalur kurva tali — tidak perlu bidikan presisi.",
            },
            {
              icon: MoveDown,
              title: "Curved sliding",
              body: "Gravitasi diproyeksikan ke garis singgung kurva, sehingga manik meluncur mulus mengikuti lekukan tali.",
            },
            {
              icon: Layers,
              title: "Menumpuk rapi",
              body: "Manik saling mendorong dan berhenti di slot terendah yang kosong, seperti tumpukan manik di tali nyata.",
            },
          ].map((f) => (
            <div key={f.title} className="border-t border-[#F8F7E5]/25 pt-5">
              <f.icon className="h-5 w-5 text-[#B39C4F]" aria-hidden />
              <h3 className="mt-3 font-mono text-sm font-bold uppercase tracking-[0.14em]">
                {f.title}
              </h3>
              <p className="mt-2 text-base leading-relaxed text-[#F8F7E5]/70">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---- Footer ---- */}
      <footer className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-8 sm:px-6">
        <span className="font-display text-base font-semibold">Manik Studio</span>
        <span className="meta-label text-foreground/50">
          16 variasi manik · 3 media dasar · dirangkai dengan gravitasi
        </span>
      </footer>
    </div>
  );
}
