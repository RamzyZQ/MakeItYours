import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { toast } from "sonner";
import AppHeader from "@/components/AppHeader";
import DesignPreview from "@/components/DesignPreview";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { BASE_TYPE_LABELS, type BaseType, type BeadRecord } from "@contracts/beads";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, Trash2 } from "lucide-react";

const dateFmt = new Intl.DateTimeFormat("id-ID", {
  day: "numeric",
  month: "long",
  year: "numeric",
});

function parseBeads(json: string): BeadRecord[] {
  try {
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function Gallery() {
  const { isAuthenticated, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
  });
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const listQuery = trpc.design.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const [deleteId, setDeleteId] = useState<number | null>(null);
  const deleteMutation = trpc.design.remove.useMutation({
    onSuccess: async () => {
      toast.success("Desain dihapus.");
      setDeleteId(null);
      await utils.design.list.invalidate();
    },
    onError: () => toast.error("Gagal menghapus desain."),
  });

  const designs = listQuery.data ?? [];

  return (
    <div className="grain min-h-dvh bg-background">
      <AppHeader />

      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="meta-label text-foreground/60">Koleksi tersimpan</p>
            <h1 className="mt-3 font-display text-5xl font-black tracking-tight">
              Galeri Saya
            </h1>
          </div>
          <Link to="/#pilih" className="btn-pill-gold">
            Buat Rangkaian Baru
            <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
        </div>

        <div className="mt-10">
          {authLoading || listQuery.isLoading ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-64 rounded-[13.5px]" />
              ))}
            </div>
          ) : listQuery.isError ? (
            <div className="rounded-[13.5px] border border-destructive/50 p-8 text-center">
              <p className="font-display text-xl">Gagal memuat galeri</p>
              <p className="mt-2 text-foreground/60">Periksa koneksimu lalu coba lagi.</p>
              <Button
                variant="outline"
                className="mt-4 rounded-[13.5px]"
                onClick={() => listQuery.refetch()}
              >
                Muat Ulang
              </Button>
            </div>
          ) : designs.length === 0 ? (
            <div className="rounded-[13.5px] border border-dashed border-foreground/40 p-12 text-center">
              <svg viewBox="-40 -40 80 80" className="mx-auto h-16 w-16 opacity-40" aria-hidden>
                <circle r="26" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="2.7" />
                <circle r="8" fill="#B39C4F" />
              </svg>
              <p className="mt-4 font-display text-2xl font-semibold">Belum ada rangkaian</p>
              <p className="mx-auto mt-2 max-w-[40ch] text-foreground/60">
                Pilih media dasar, rangkai manik favoritmu, lalu simpan — desain
                akan muncul di sini.
              </p>
              <Link to="/#pilih" className="btn-pill-gold mt-6">
                Mulai Merangkai
              </Link>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {designs.map((d) => (
                <article
                  key={d.id}
                  className="group flex flex-col rounded-[13.5px] border border-foreground/70 bg-card transition-colors duration-150 hover:bg-foreground"
                >
                  <button
                    type="button"
                    onClick={() => navigate(`/builder/${d.baseType}?desain=${d.id}`)}
                    className="block p-4 text-left"
                    aria-label={`Buka desain ${d.name} di studio`}
                  >
                    <div className="overflow-hidden rounded-[10px] bg-background">
                      <DesignPreview
                        base={d.baseType as BaseType}
                        beads={parseBeads(d.beads)}
                        uidPrefix={`gal-${d.id}`}
                      />
                    </div>
                    <h2 className="mt-4 font-display text-xl font-semibold leading-snug group-hover:text-background">
                      {d.name}
                    </h2>
                    <p className="meta-label mt-2 text-foreground/55 group-hover:text-background/60">
                      {BASE_TYPE_LABELS[d.baseType as BaseType] ?? d.baseType} · {d.beadCount}{" "}
                      manik · {dateFmt.format(new Date(d.updatedAt))}
                    </p>
                  </button>
                  <div className="mt-auto flex items-center justify-between border-t border-foreground/15 px-4 py-3 group-hover:border-background/20">
                    <span className="meta-label flex items-center gap-1.5 text-primary">
                      Buka di studio
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" aria-hidden />
                    </span>
                    <button
                      type="button"
                      onClick={() => setDeleteId(d.id)}
                      className="meta-label flex items-center gap-1.5 rounded-[13.5px] px-2 py-2 text-foreground/50 transition-colors hover:text-destructive group-hover:text-background/60 group-hover:hover:text-destructive"
                      aria-label={`Hapus desain ${d.name}`}
                    >
                      <Trash2 className="h-4 w-4" aria-hidden />
                      Hapus
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* delete confirm */}
      <Dialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <DialogContent className="rounded-[13.5px]">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Hapus desain ini?</DialogTitle>
            <DialogDescription>
              Desain yang dihapus tidak bisa dikembalikan. Rangkaian maniknya akan
              hilang dari galeri.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setDeleteId(null)}
              className="rounded-[13.5px]"
              disabled={deleteMutation.isPending}
            >
              Batal
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteId !== null && deleteMutation.mutate({ id: deleteId })}
              className="rounded-[13.5px]"
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Menghapus…" : "Ya, Hapus"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
