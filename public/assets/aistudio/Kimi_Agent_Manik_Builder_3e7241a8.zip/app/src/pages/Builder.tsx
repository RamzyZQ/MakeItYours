import { useCallback, useEffect, useRef, useState } from "react";
import { Link, Navigate, useNavigate, useParams, useSearchParams } from "react-router";
import { toast } from "sonner";
import AppHeader from "@/components/AppHeader";
import StringCanvas from "@/components/StringCanvas";
import { BeadCatalog } from "@/components/BeadCatalog";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { getPath, nearestS, topS, VIEW_H, VIEW_W } from "@/game/paths";
import { BeadGlyph, type BeadDef } from "@/game/beads";
import { useStringSim } from "@/game/sim";
import {
  BASE_TYPES,
  BASE_TYPE_LABELS,
  MAX_BEADS_PER_DESIGN,
  type BaseType,
  type BeadRecord,
} from "@contracts/beads";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Eraser, Save, Undo2 } from "lucide-react";

export default function Builder() {
  const { base } = useParams<{ base: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  if (!base || !BASE_TYPES.includes(base as BaseType)) {
    return <Navigate to="/" replace />;
  }
  return (
    <BuilderInner
      key={base}
      base={base as BaseType}
      designId={Number(searchParams.get("desain")) || null}
      setDesignParam={(id) => setSearchParams(id ? { desain: String(id) } : {}, { replace: true })}
      isAuthenticated={isAuthenticated}
      authLoading={authLoading}
      navigate={navigate}
    />
  );
}

function BuilderInner({
  base,
  designId,
  setDesignParam,
  isAuthenticated,
  authLoading,
  navigate,
}: {
  base: BaseType;
  designId: number | null;
  setDesignParam: (id: number | null) => void;
  isAuthenticated: boolean;
  authLoading: boolean;
  navigate: ReturnType<typeof useNavigate>;
}) {
  const path = getPath(base);
  const sim = useStringSim(path);
  const utils = trpc.useUtils();

  const svgRef = useRef<SVGSVGElement>(null);
  const dragRef = useRef<{ def: BeadDef } | null>(null);
  const countRef = useRef(0);
  const [ghost, setGhost] = useState<{ def: BeadDef; x: number; y: number } | null>(null);
  const [overCanvas, setOverCanvas] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [designName, setDesignName] = useState("");
  const [loadedId, setLoadedId] = useState<number | null>(null);

  useEffect(() => {
    countRef.current = sim.beads.length;
  }, [sim.beads.length]);

  // ---------- drag & drop (pointer based, works for mouse + touch) ----------
  useEffect(() => {
    const insideCanvas = (x: number, y: number) => {
      const rect = svgRef.current?.getBoundingClientRect();
      if (!rect) return null;
      if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) return null;
      return {
        vx: ((x - rect.left) / rect.width) * VIEW_W,
        vy: ((y - rect.top) / rect.height) * VIEW_H,
      };
    };

    const move = (e: PointerEvent) => {
      if (!dragRef.current) return;
      setGhost((g) => (g ? { ...g, x: e.clientX, y: e.clientY } : g));
      setOverCanvas(insideCanvas(e.clientX, e.clientY) !== null);
    };

    const up = (e: PointerEvent) => {
      const drag = dragRef.current;
      if (!drag) return;
      dragRef.current = null;
      setGhost(null);
      setOverCanvas(false);
      const pos = insideCanvas(e.clientX, e.clientY);
      if (!pos) return;
      if (countRef.current >= MAX_BEADS_PER_DESIGN) {
        toast.warning("Tali sudah penuh — lepas dulu manik yang ada.");
        return;
      }
      sim.addBead(drag.def.id, nearestS(path, pos.vx, pos.vy));
    };

    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [path, sim]);

  const startDrag = useCallback((def: BeadDef, x: number, y: number) => {
    dragRef.current = { def };
    setGhost({ def, x, y });
  }, []);

  const pickBead = useCallback(
    (def: BeadDef) => {
      if (countRef.current >= MAX_BEADS_PER_DESIGN) {
        toast.warning("Tali sudah penuh — lepas dulu manik yang ada.");
        return;
      }
      // click / tap fallback: drop near the top of the string and let it slide
      const jitter = (Math.random() - 0.5) * path.length * 0.12;
      sim.addBead(def.id, topS(path) + jitter);
    },
    [path, sim],
  );

  // ---------- load a saved design ----------
  const designQuery = trpc.design.byId.useQuery(
    { id: designId! },
    { enabled: !!designId && isAuthenticated, retry: false },
  );

  useEffect(() => {
    if (designId && !authLoading && !isAuthenticated) {
      toast.info("Masuk dulu untuk membuka desain tersimpan.");
      navigate("/login");
    }
  }, [designId, authLoading, isAuthenticated, navigate]);

  useEffect(() => {
    const data = designQuery.data;
    if (!data) return;
    try {
      const records = JSON.parse(data.beads) as BeadRecord[];
      if (data.baseType === base) {
        sim.loadBeads(records);
        setDesignName(data.name);
        setLoadedId(data.id);
      } else {
        toast.error("Media dasar desain tidak cocok.");
      }
    } catch {
      toast.error("Gagal membaca desain.");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [designQuery.data]);

  // ---------- save ----------
  const createMutation = trpc.design.create.useMutation({
    onSuccess: async ({ id }) => {
      toast.success("Desain tersimpan di galeri.");
      setLoadedId(id);
      setDesignParam(id);
      setSaveOpen(false);
      await utils.design.list.invalidate();
    },
    onError: () => toast.error("Gagal menyimpan desain. Coba lagi."),
  });

  const updateMutation = trpc.design.update.useMutation({
    onSuccess: async () => {
      toast.success("Perubahan tersimpan.");
      setSaveOpen(false);
      await utils.design.list.invalidate();
    },
    onError: () => toast.error("Gagal menyimpan perubahan. Coba lagi."),
  });

  const handleSaveClick = () => {
    if (sim.beads.length === 0) {
      toast.warning("Rangkaian masih kosong — tambahkan manik dulu.");
      return;
    }
    if (!isAuthenticated) {
      toast.info("Masuk dulu untuk menyimpan desainmu.");
      navigate("/login");
      return;
    }
    setSaveOpen(true);
  };

  const submitSave = () => {
    const name = designName.trim() || "Rangkaian tanpa nama";
    const beads: BeadRecord[] = sim.beads.map((b) => ({ type: b.type, s: Math.round(b.s) }));
    if (loadedId) {
      updateMutation.mutate({ id: loadedId, name, beads });
    } else {
      createMutation.mutate({ name, baseType: base, beads });
    }
  };

  const saving = createMutation.isPending || updateMutation.isPending;
  const count = sim.beads.length;

  return (
    <div className="grain flex min-h-dvh flex-col bg-background">
      <AppHeader />

      {/* toolbar */}
      <div className="border-b border-border">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-4 py-3 sm:px-6">
          <Link
            to="/"
            className="btn-pill-ghost !min-h-10 px-3"
            aria-label="Kembali ke pilihan media dasar"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">Ganti Tali</span>
          </Link>
          <div className="mx-2 h-6 w-px bg-border" aria-hidden />
          <div>
            <p className="font-display text-lg font-semibold leading-tight">
              {designName || BASE_TYPE_LABELS[base]}
            </p>
            <p className="meta-label text-[10px] text-foreground/55">
              {count}/{MAX_BEADS_PER_DESIGN} manik{loadedId ? " · tersimpan" : ""}
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={sim.undo}
              disabled={!sim.canUndo}
              className="rounded-[13.5px] font-mono text-xs uppercase tracking-wider"
            >
              <Undo2 className="h-4 w-4" aria-hidden />
              Urungkan
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={sim.clear}
              disabled={count === 0}
              className="rounded-[13.5px] font-mono text-xs uppercase tracking-wider"
            >
              <Eraser className="h-4 w-4" aria-hidden />
              Bersihkan
            </Button>
            <button type="button" onClick={handleSaveClick} className="btn-pill-gold !min-h-9 px-4">
              <Save className="h-4 w-4" aria-hidden />
              Simpan
            </button>
          </div>
        </div>
      </div>

      {/* workspace: catalog left, canvas right (canvas first on mobile) */}
      <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col-reverse lg:flex-row">
        <aside className="border-t border-border p-4 sm:px-6 lg:w-[320px] lg:border-r lg:border-t-0 xl:w-[360px]">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="meta-label text-foreground/60">Katalog manik</h2>
            <span className="meta-label text-[10px] text-foreground/40">16 variasi</span>
          </div>
          <BeadCatalog onPick={pickBead} onDragStart={startDrag} />
          <p className="mt-4 font-mono text-[11px] leading-relaxed text-foreground/50">
            Seret manik ke tali, atau ketuk untuk menjatuhkannya dari atas.
            Klik manik di tali untuk melepasnya.
          </p>
        </aside>

        <main className="flex flex-1 items-center p-4 sm:p-6 lg:p-8">
          <div className="w-full">
            <StringCanvas
              ref={svgRef}
              path={path}
              beads={sim.beads}
              tone="dark"
              highlight={overCanvas}
              onBeadClick={(id) => sim.removeBead(id)}
              hint="Jatuhkan manik di sini"
            />
            <p className="meta-label mt-3 text-center text-foreground/45">
              {BASE_TYPE_LABELS[base]} · gravitasi kurva aktif
            </p>
          </div>
        </main>
      </div>

      {/* drag ghost */}
      {ghost && (
        <div
          className="pointer-events-none fixed left-0 top-0 z-50"
          style={{ transform: `translate(${ghost.x - 34}px, ${ghost.y - 44}px)` }}
          aria-hidden
        >
          <svg
            viewBox="-38 -38 76 76"
            className="h-[68px] w-[68px] drop-shadow-[0_10px_14px_rgba(29,29,29,0.35)]"
          >
            <BeadGlyph def={ghost.def} uid="ghost" />
          </svg>
          <span className="meta-label mt-1 block rounded bg-foreground px-1.5 py-0.5 text-center text-[9px] text-background">
            {ghost.def.name}
          </span>
        </div>
      )}

      {/* save dialog */}
      <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
        <DialogContent className="rounded-[13.5px]">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">
              {loadedId ? "Simpan perubahan" : "Simpan rangkaian"}
            </DialogTitle>
            <DialogDescription>
              {loadedId
                ? "Perubahan akan menimpa desain tersimpan di galerimu."
                : "Desain akan tersimpan di galeri dan bisa dibuka kembali kapan saja."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-2 py-2">
            <Label htmlFor="design-name" className="meta-label">
              Nama rangkaian
            </Label>
            <Input
              id="design-name"
              value={designName}
              onChange={(e) => setDesignName(e.target.value)}
              placeholder="cth. Kalung Senja untuk Ibu"
              maxLength={120}
              className="rounded-[13.5px]"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !saving) submitSave();
              }}
            />
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setSaveOpen(false)}
              className="rounded-[13.5px]"
              disabled={saving}
            >
              Batal
            </Button>
            <button
              type="button"
              onClick={submitSave}
              disabled={saving}
              className="btn-pill-gold !min-h-10 disabled:opacity-60"
            >
              {saving ? "Menyimpan…" : "Simpan"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
