import { useMemo } from "react";
import { getPath, pointAt, VIEW_H, VIEW_W } from "@/game/paths";
import { getBead, BeadGlyph } from "@/game/beads";
import type { BaseType, BeadRecord } from "@contracts/beads";

/** Static miniature render of a saved design (string + beads at rest). */
export default function DesignPreview({
  base,
  beads,
  uidPrefix,
}: {
  base: BaseType;
  beads: BeadRecord[];
  uidPrefix: string;
}) {
  const path = getPath(base);

  const placed = useMemo(
    () =>
      beads.map((b, i) => ({
        def: getBead(b.type),
        p: pointAt(path, b.s),
        i,
      })),
    [beads, path],
  );

  return (
    <svg
      viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
      className="block h-auto w-full"
      role="img"
      aria-label="Pratinjau desain"
    >
      <path d={path.d} className="string-line-static" stroke="#1D1D1D" opacity={0.8} />
      {!path.closed && (
        <>
          <circle cx={path.samples[0].x} cy={path.samples[0].y} r={9} fill="#B39C4F" />
          <circle
            cx={path.samples[path.samples.length - 1].x}
            cy={path.samples[path.samples.length - 1].y}
            r={9}
            fill="#B39C4F"
          />
        </>
      )}
      {placed.map(({ def, p, i }) => (
        <g key={i} transform={`translate(${p.x.toFixed(1)} ${p.y.toFixed(1)})`}>
          <BeadGlyph def={def} uid={`${uidPrefix}-${i}`} />
        </g>
      ))}
    </svg>
  );
}
