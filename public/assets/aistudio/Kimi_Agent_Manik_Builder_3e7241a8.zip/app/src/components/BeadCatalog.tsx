import { BEADS, BeadGlyph, type BeadDef } from "@/game/beads";

interface BeadCatalogProps {
  onPick: (def: BeadDef) => void;
  onDragStart: (def: BeadDef, x: number, y: number) => void;
  disabled?: boolean;
}

export function BeadCatalog({ onPick, onDragStart, disabled }: BeadCatalogProps) {
  return (
    <div className="grid grid-cols-3 gap-1 sm:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4">
      {BEADS.map((def) => (
        <button
          key={def.id}
          type="button"
          className="bead-item"
          disabled={disabled}
          aria-label={`Tambah ${def.name}`}
          onPointerDown={(e) => {
            e.preventDefault();
            onDragStart(def, e.clientX, e.clientY);
          }}
          onClick={() => onPick(def)}
        >
          <svg viewBox="-34 -34 68 68" className="h-12 w-12" aria-hidden>
            <BeadGlyph def={def} uid={`cat-${def.id}`} />
          </svg>
          <span className="meta-label text-[9px] text-foreground/70">{def.name}</span>
        </button>
      ))}
    </div>
  );
}
