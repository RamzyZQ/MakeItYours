import { Link, NavLink, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LogOut, LayoutGrid } from "lucide-react";

export default function AppHeader() {
  const { user, isAuthenticated, logout, isLoading } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="rule-y sticky top-0 z-40 bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-3" aria-label="Manik Studio — beranda">
          <svg viewBox="-20 -20 40 40" className="h-8 w-8" aria-hidden>
            <circle r="14" fill="#B39C4F" />
            <circle r="6" fill="#F8F7E5" />
          </svg>
          <span className="whitespace-nowrap font-display text-lg font-semibold tracking-tight">
            Manik Studio
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2" aria-label="Navigasi utama">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `meta-label rounded-[13.5px] px-3 py-2.5 transition-colors hover:bg-foreground/5 ${
                isActive ? "text-foreground" : "text-foreground/55"
              }`
            }
          >
            Beranda
          </NavLink>
          <NavLink
            to="/galeri"
            className={({ isActive }) =>
              `meta-label rounded-[13.5px] px-3 py-2.5 transition-colors hover:bg-foreground/5 ${
                isActive ? "text-foreground" : "text-foreground/55"
              }`
            }
          >
            Galeri
          </NavLink>

          {!isLoading && isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger className="ml-1 rounded-full focus-visible:outline-2 focus-visible:outline-ring">
                <Avatar className="h-10 w-10 border border-foreground/20">
                  <AvatarFallback className="bg-primary font-mono text-sm text-primary-foreground">
                    {(user.name ?? "M").slice(0, 1).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={() => navigate("/galeri")} className="cursor-pointer gap-2">
                  <LayoutGrid className="h-4 w-4" />
                  Galeri Saya
                </DropdownMenuItem>
                <DropdownMenuItem onClick={logout} className="cursor-pointer gap-2 text-destructive">
                  <LogOut className="h-4 w-4" />
                  Keluar
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link to="/login" className="btn-pill-gold ml-2 !min-h-10 px-4">
              Masuk
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
