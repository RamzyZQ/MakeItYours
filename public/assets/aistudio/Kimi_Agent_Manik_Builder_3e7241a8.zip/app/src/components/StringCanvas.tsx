import { forwardRef, useMemo } from "react";
import { pointAt, tangentAt, VIEW_H, VIEW_W, type PathData } from "@/game/paths";
import { getBead, BeadGlyph } from "@/game/beads";
import type { SimBead } from "@/game/sim";
import { cn } from "@/lib/utils";

/** how much each bead shape rotates with the string tangent */
const ROTATION_FACTOR: Record<string, number> = {
  oval: 1,
  cube: 0.8,
  heart: 0.45,
  star: 0.4,
  flower: 0.4,
  faceted: 0.6,
};

interface StringCanvasProps {
  path: PathData;
  beads: SimBead[];
  /** dark velvet mat (builder) or light card (preview) */
  tone?: "dark" | "light";
  highlight?: boolean;
  beadScale?: number;
  onBeadClick?: (id: string) => void;
  hint?: string;
  staticString?: boolean;
}

const StringCanvas = forwardRef<SVGSVGElement, StringCanvasProps>(
  function StringCanvas(
    {
      path,
      beads,
      tone = "dark",
      highlight = false,
      beadScale = 1,
      onBeadClick,
      hint,
      staticString = false,
    },
    ref,
  ) {
    const dark = tone === "dark";
    const stringColor = dark ? "#F8F7E5" : "#1D1D1D";

    const rendered = useMemo(
      () =>
        beads.map((b) => {
          const def = getBead(b.type);
          const p = pointAt(path, b.s);
          const t = tangentAt(path, b.s);
          const deg =
            (Math.atan2(t.y, t.x) * 180) / Math.PI *
            (ROTATION_FACTOR[def.shape] ?? 0);
          return { b, def, p, deg };
        }),
      [beads, path],
    );

    const ends = useMemo(
      () =>
        path.closed
          ? null
          : ([pointAt(path, 0), pointAt(path, path.length)] as const),
      [path],
    );

    return (
      <div
        className={cn(
          "relative overflow-hidden rounded-[13.5px] transition-shadow duration-200",
          dark ? "bg-[#1D1D1D]" : "bg-transparent",
          highlight && "ring-2 ring-[#B39C4F] ring-offset-2 ring-offset-transparent",
        )}
      >
        <svg
          ref={ref}
          viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
          className="block h-auto w-full"
          role="img"
          aria-label="Kanvas tali aksesori"
        >
          {/* the string */}
          <path
            d={path.d}
            className={staticString ? "string-line-static" : "string-line"}
            stroke={stringColor}
            opacity={0.85}
          />
          {/* end knots for open strings */}
          {ends?.map((p, i) => (
            <g key={i}>
              <circle cx={p.x} cy={p.y} r={9} fill="#B39C4F" />
              <circle cx={p.x} cy={p.y} r={4} fill={dark ? "#1D1D1D" : "#F8F7E5"} />
            </g>
          ))}
          {/* beads on the string */}
          {rendered.map(({ b, def, p, deg }) => (
            <g
              key={b.id}
              transform={`translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) rotate(${deg.toFixed(1)}) scale(${beadScale})`}
              onClick={onBeadClick ? () => onBeadClick(b.id) : undefined}
              className={onBeadClick ? "cursor-pointer" : undefined}
              style={onBeadClick ? { pointerEvents: "all" } : undefined}
            >
              <title>{def.name} — klik untuk melepas</title>
              <BeadGlyph def={def} uid={b.id} />
            </g>
          ))}
        </svg>
        {hint && beads.length === 0 && (
          <p className="meta-label pointer-events-none absolute inset-x-0 bottom-4 text-center text-[#F8F7E5]/50">
            {hint}
          </p>
        )}
      </div>
    );
  },
);

export default StringCanvas;
