// Bead catalog: definitions + SVG glyph rendering for each bead variety.

export type BeadShape =
  | "round"
  | "faceted"
  | "cube"
  | "star"
  | "heart"
  | "donut"
  | "oval"
  | "flower";

export interface BeadDef {
  id: string;
  name: string;
  shape: BeadShape;
  /** main body color */
  color: string;
  /** darker shade for depth */
  shade: string;
  /** highlight color */
  light: string;
  /** radius in canvas viewBox units */
  r: number;
}

export const BEADS: BeadDef[] = [
  { id: "garnet-round", name: "Garnet Bulat", shape: "round", color: "#8E2A32", shade: "#5C1A20", light: "#C05A62", r: 26 },
  { id: "coral-round", name: "Koral Bulat", shape: "round", color: "#D96C4F", shade: "#A04529", light: "#F0A184", r: 26 },
  { id: "amber-faceted", name: "Amber Facet", shape: "faceted", color: "#D9A441", shade: "#A07422", light: "#F2CE7E", r: 27 },
  { id: "ochre-cube", name: "Oker Kubus", shape: "cube", color: "#B39C4F", shade: "#83702F", light: "#D6C384", r: 25 },
  { id: "moss-round", name: "Lumut Bulat", shape: "round", color: "#6F7F4E", shade: "#4A5731", light: "#9BAF77", r: 26 },
  { id: "sage-flower", name: "Sage Bunga", shape: "flower", color: "#9CAF88", shade: "#6E8259", light: "#C4D4B2", r: 28 },
  { id: "teal-donut", name: "Teal Donat", shape: "donut", color: "#3E7C7B", shade: "#26514F", light: "#6FA9A7", r: 28 },
  { id: "lapis-faceted", name: "Lapis Facet", shape: "faceted", color: "#37507E", shade: "#22314F", light: "#6B84B5", r: 27 },
  { id: "peri-round", name: "Peri Bulat", shape: "round", color: "#98B8FE", shade: "#6486D6", light: "#C2D4FF", r: 26 },
  { id: "clay-heart", name: "Hati Tanah", shape: "heart", color: "#D98E96", shade: "#A95F68", light: "#EFB9BE", r: 26 },
  { id: "plum-star", name: "Bintang Plum", shape: "star", color: "#7A4E63", shade: "#503040", light: "#A97E93", r: 28 },
  { id: "terra-cube", name: "Tera Kubus", shape: "cube", color: "#B5563C", shade: "#7F3622", light: "#D8856C", r: 25 },
  { id: "ivory-oval", name: "Gading Oval", shape: "oval", color: "#F2EDDA", shade: "#C9BFA0", light: "#FFFFFF", r: 26 },
  { id: "charcoal-round", name: "Arang Bulat", shape: "round", color: "#33302B", shade: "#171512", light: "#5C564C", r: 26 },
  { id: "sky-donut", name: "Langit Donat", shape: "donut", color: "#8FB8C9", shade: "#5E879A", light: "#BBD9E4", r: 28 },
  { id: "lilac-star", name: "Bintang Lila", shape: "star", color: "#B9A7CE", shade: "#8A76A6", light: "#D8CCE6", r: 28 },
];

export const BEAD_MAP: Record<string, BeadDef> = Object.fromEntries(
  BEADS.map((b) => [b.id, b]),
);

export function getBead(id: string): BeadDef {
  return BEAD_MAP[id] ?? BEADS[0];
}

function starPath(r: number, points = 5): string {
  const inner = r * 0.48;
  let d = "";
  for (let i = 0; i < points * 2; i++) {
    const rad = i % 2 === 0 ? r : inner;
    const a = (Math.PI / points) * i - Math.PI / 2;
    const x = Math.cos(a) * rad;
    const y = Math.sin(a) * rad;
    d += `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`;
  }
  return d + "Z";
}

function heartPath(r: number): string {
  const s = r / 30;
  return [
    `M0,${(26 * s).toFixed(2)}`,
    `C${(-40 * s).toFixed(2)},${(2 * s).toFixed(2)} ${(-22 * s).toFixed(2)},${(-30 * s).toFixed(2)} 0,${(-12 * s).toFixed(2)}`,
    `C${(22 * s).toFixed(2)},${(-30 * s).toFixed(2)} ${(40 * s).toFixed(2)},${(2 * s).toFixed(2)} 0,${(26 * s).toFixed(2)}Z`,
  ].join(" ");
}

/**
 * Renders one bead centered at (0,0). Wrap it in a <g transform> to place it.
 * `uid` keeps gradient ids unique per instance.
 */
export function BeadGlyph({ def, uid }: { def: BeadDef; uid: string }) {
  const gid = `bg-${uid}`;
  const r = def.r;
  const common = (
    <>
      <defs>
        <radialGradient id={gid} cx="35%" cy="30%" r="80%">
          <stop offset="0%" stopColor={def.light} />
          <stop offset="55%" stopColor={def.color} />
          <stop offset="100%" stopColor={def.shade} />
        </radialGradient>
      </defs>
    </>
  );

  switch (def.shape) {
    case "round":
      return (
        <>
          {common}
          <circle r={r} fill={`url(#${gid})`} />
          <ellipse cx={-r * 0.32} cy={-r * 0.38} rx={r * 0.3} ry={r * 0.18} fill="#fff" opacity={0.55} transform={`rotate(-24 ${-r * 0.32} ${-r * 0.38})`} />
        </>
      );
    case "faceted": {
      const pts = Array.from({ length: 8 }, (_, i) => {
        const a = (Math.PI / 4) * i - Math.PI / 2;
        return `${(Math.cos(a) * r).toFixed(2)},${(Math.sin(a) * r).toFixed(2)}`;
      }).join(" ");
      const innerPts = Array.from({ length: 8 }, (_, i) => {
        const a = (Math.PI / 4) * i - Math.PI / 2;
        return `${(Math.cos(a) * r * 0.55).toFixed(2)},${(Math.sin(a) * r * 0.55).toFixed(2)}`;
      }).join(" ");
      return (
        <>
          {common}
          <polygon points={pts} fill={`url(#${gid})`} />
          <polygon points={innerPts} fill={def.light} opacity={0.5} />
        </>
      );
    }
    case "cube":
      return (
        <>
          {common}
          <rect x={-r * 0.86} y={-r * 0.86} width={r * 1.72} height={r * 1.72} rx={r * 0.28} fill={`url(#${gid})`} />
          <rect x={-r * 0.55} y={-r * 0.55} width={r * 1.1} height={r * 1.1} rx={r * 0.2} fill={def.light} opacity={0.35} />
        </>
      );
    case "star":
      return (
        <>
          {common}
          <path d={starPath(r)} fill={`url(#${gid})`} stroke={def.shade} strokeWidth={1.5} strokeLinejoin="round" />
          <circle cx={-r * 0.15} cy={-r * 0.2} r={r * 0.16} fill="#fff" opacity={0.5} />
        </>
      );
    case "heart":
      return (
        <>
          {common}
          <path d={heartPath(r)} fill={`url(#${gid})`} stroke={def.shade} strokeWidth={1.5} strokeLinejoin="round" />
          <ellipse cx={-r * 0.3} cy={-r * 0.25} rx={r * 0.18} ry={r * 0.1} fill="#fff" opacity={0.55} transform={`rotate(-30 ${-r * 0.3} ${-r * 0.25})`} />
        </>
      );
    case "donut":
      return (
        <>
          {common}
          <path
            d={`M${-r},0 A${r},${r} 0 1,0 ${r},0 A${r},${r} 0 1,0 ${-r},0 Z M${-r * 0.34},0 A${r * 0.34},${r * 0.34} 0 1,1 ${r * 0.34},0 A${r * 0.34},${r * 0.34} 0 1,1 ${-r * 0.34},0 Z`}
            fill={`url(#${gid})`}
            fillRule="evenodd"
          />
          <circle r={r * 0.34} fill="none" stroke={def.shade} strokeWidth={2} />
          <ellipse cx={-r * 0.4} cy={-r * 0.55} rx={r * 0.22} ry={r * 0.12} fill="#fff" opacity={0.5} transform={`rotate(-30 ${-r * 0.4} ${-r * 0.55})`} />
        </>
      );
    case "oval":
      return (
        <>
          {common}
          <ellipse rx={r * 1.15} ry={r * 0.78} fill={`url(#${gid})`} />
          <ellipse cx={-r * 0.35} cy={-r * 0.3} rx={r * 0.28} ry={r * 0.13} fill="#fff" opacity={0.5} transform={`rotate(-18 ${-r * 0.35} ${-r * 0.3})`} />
        </>
      );
    case "flower": {
      const petals = Array.from({ length: 6 }, (_, i) => {
        const a = (Math.PI / 3) * i;
        return { x: Math.cos(a) * r * 0.52, y: Math.sin(a) * r * 0.52 };
      });
      return (
        <>
          {common}
          {petals.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r={r * 0.46} fill={`url(#${gid})`} stroke={def.shade} strokeWidth={1} />
          ))}
          <circle r={r * 0.34} fill={def.light} stroke={def.shade} strokeWidth={1.5} />
        </>
      );
    }
  }
}
